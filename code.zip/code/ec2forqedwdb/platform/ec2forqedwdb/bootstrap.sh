#!/bin/env bash

source /root/context

echo "bootstrap execution started"

yum clean all

rm -rf /var/cache/yum

#Enable Extras repository

yum-config-manager --enable rhui-REGION-rhel-server-extras

#Download and Install python package

aws s3 cp s3://${pipeline_QdaBucketName}/OWB/11204OraSoft/python-pkg-resources-19.6.2-1.mga6.noarch.rpm /tmp/python-pkg-resources-19.6.2-1.mga6.noarch.rpm
aws s3 cp s3://${pipeline_QdaBucketName}/OWB/11204OraSoft/python-pip-8.0.2-6.mga6.noarch.rpm /tmp/python-pip-8.0.2-6.mga6.noarch.rpm

cd  /tmp
yum -y install python-pkg-resources-19.6.2-1.mga6.noarch.rpm
yum -y install python-pip-8.0.2-6.mga6.noarch.rpm
pip install --upgrade pip

# Install Ansible
yum -y install ansible
pip install ansible --upgrade

cp -r /root/payload/* /etc/ansible/
chmod 775 /etc/ansible/launch_phase.sh
cd /etc/ansible/
export ANSIBLE_LOG_PATH=/etc/ansible/bake_playbook_run.log
for dvc in `lsblk|grep -v NAME|awk -F" " '{ print "/dev/"$1}'`; do export blkdvc=`/sbin/ebsnvme-id  $dvc 2>/dev/null|tail -1 `;  if [[  $blkdvc = 'sdc' ]];then   echo "orahome_blockdevice: $dvc">>/etc/ansible/roles/Bake_Phase/vars/main.yml ;     fi; done
ansible-playbook bake_playbook.yml
