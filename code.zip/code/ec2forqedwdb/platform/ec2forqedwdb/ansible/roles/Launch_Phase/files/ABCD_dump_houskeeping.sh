#!/bin/bash

#Author : Rajib Podder Date : 01/01/2017 Version : 1.1

adump_purge()
{

Audit_Loc=`${ORACLE_HOME}/bin/sqlplus -s / as sysdba <<EOF | sed '/^$/d'| tr -d ' '
set feed off hea off pages 0
select value from v\\$parameter where name='audit_file_dest';
exit
EOF`

find ${Audit_Loc} -type f -name "*.aud" -mtime +15|xargs rm -f

}

bcudump_purge()
{

DBVersion=`${ORACLE_HOME}/bin/sqlplus -s / as sysdba <<EOF | sed '/^$/d'| tr -d ' '|cut -d"." -f1
set feed off hea off pages 0
select version from v\\$instance;
exit
EOF`


if [ ${DBVersion} -lt 11 ]
then

BDump_Loc=`${ORACLE_HOME}/bin/sqlplus -s / as sysdba <<EOF | sed '/^$/d'| tr -d ' '
set feed off hea off pages 0
select value from v\\$parameter where name='background_dump_dest';
exit
EOF`

UDump_Loc=`${ORACLE_HOME}/bin/sqlplus -s / as sysdba <<EOF | sed '/^$/d'| tr -d ' '
set feed off hea off pages 0
select value from v\\$parameter where name='user_dump_dest';
exit
EOF`

CDump_Loc=`${ORACLE_HOME}/bin/sqlplus -s / as sysdba <<EOF | sed '/^$/d'| tr -d ' '
set feed off hea off pages 0
select value from v\\$parameter where name='core_dump_dest';
exit
EOF`

echo $BDump_Loc $UDump_Loc $CDump_Loc

find ${BDump_Loc} -type f -name "*.trc" -mtime +15|xargs rm -rf
find ${BDump_Loc} -type f -name "*.trm" -mtime +15|xargs rm -rf
find ${CDump_Loc} -type d -name "core_*" -mtime +15|xargs rm -rf
find ${UDump_Loc} -type f -name "*.trc" -mtime +15|xargs rm -rf
find ${UDump_Loc} -type f -name "*.trm" -mtime +15|xargs rm -rf

else


TRace_Loc=`${ORACLE_HOME}/bin/sqlplus -s / as sysdba <<EOF | sed '/^$/d'| tr -d ' '
set feed off hea off pages 0
select value from v\\$diag_info where name in ('Diag Trace');
exit
EOF`

CDump_Loc=`${ORACLE_HOME}/bin/sqlplus -s / as sysdba <<EOF | sed '/^$/d'| tr -d ' '
set feed off hea off pages 0
select value from v\\$diag_info where name in ('Diag Cdump');
exit
EOF`

find ${TRace_Loc} -type f -name "*.trc" -mtime +15|xargs rm -rf
find ${TRace_Loc} -type f -name "*.trm" -mtime +15|xargs rm -rf
find ${CDump_Loc} -type d -name "core_*" -mtime +15|xargs rm -rf

fi

}



LOGDIR=`dirname $0`

export LOGDIR

OsType=`uname`;export OsType


case "$1" in

'rdbms')

ps -ef|grep ora_pmon|grep -v grep|cut -d"_" -f3|sed '/^$/d' >${LOGDIR}/RunningInstance.lst

for INST in `cat ${LOGDIR}/RunningInstance.lst`

do


        if [ ${OsType} = 'AIX' ]
                 then
                        PID=`ps -ef|grep ora_pmon|grep -v grep|grep -i ${INST}|awk -F" " '{print $2}'`
                        OH=`ps ewww $PID|tail -1|tr -s ' '|tr ' ' '\n'|grep -w "ORACLE_HOME"|cut -d"=" -f2`

        elif [ ${OsType} = 'SunOS' ]
                 then
                        PID=`ps -ef|grep ora_pmon|grep -v grep|grep -i ${INST}|awk -F" " '{print $2}'`
                        OH=`pargs -e ${PID}|grep -w "ORACLE_HOME"|cut -d"=" -f2`

        else

                        PID=`ps -ef|grep ora_pmon|grep -v grep|grep -i ${INST}|awk -F" " '{print $2}'`
                        OH=`strings -a /proc/${PID}/environ|grep -w "ORACLE_HOME"|cut -d"=" -f2`
        fi


                        ORACLE_HOME=${OH};export ORACLE_HOME
                        ORACLE_SID=${INST};export ORACLE_SID

###Function call to purge adump,bdump,cdump and udump trace files

                        adump_purge
                        bcudump_purge

done
;;

*)
echo " "
echo "You have not entered Any Argument else Script Argument is not appropriate."
echo " "
;;

esac