#!/bin/bash

cd /etc/ansible
for dvc in `lsblk|grep -v NAME|awk -F" " '{ print "/dev/"$1}'`; do export blkdvc=`/sbin/ebsnvme-id  $dvc 2>/dev/null|tail -1 `;  if [[  $blkdvc = '/dev/xvdp' ]];then   echo "oradata_blockdevice: $dvc">>/etc/ansible/roles/Launch_Phase/defaults/main.yml  ;     fi; done
export ANSIBLE_LOG_PATH=/etc/ansible/launch_playbook_run.log
ansible-playbook launch_playbook.yml

