#!/bin/bash
set -e

echo " --- start build.sh ---"
echo " Executing on Bamboo Agent: $(uname -n)"
echo " Running Application build script: $0"
echo " Parameters: $@"

export HOME=$(pwd)
echo $HOME

# Setup proxy
export HTTP_PROXY="$bamboo_agent_proxy"
export HTTPS_PROXY="$bamboo_agent_proxy"
export no_proxy="nexus.qcpaws.qantas.com.au"

# Setup NVM
echo "> Install NVM"

export NVM_DIR="${bamboo_build_working_directory}/.nvm" && (
  git clone https://github.com/creationix/nvm.git "$NVM_DIR"
  cd "$NVM_DIR"
  git checkout $(git describe --abbrev=0 --tags --match "v[0-9]*")
) && \. "$NVM_DIR/nvm.sh"

# use .nvmrc to install and use node
NODE_VERSION=`cat $APP_DIR/.nvmrc`
echo ">> nvm install "$(echo $NODE_VERSION)
nvm install $NODE_VERSION

echo ">> nvm use node"
nvm use $NODE_VERSION

echo ">> Node "$(echo $(node --version))
echo ">> NPM "$(echo $(npm --version))

####
##
# Build Application
##
###
echo "> Build lambda"

cd $APP_DIR/src
echo ">> ls lambda"
ls -ltrh

echo "> Install Deps"
npm install

echo "> Package Lambda"
zip -r $PAYLOAD_DIR/package.zip *

echo "--- end of build.sh ---"
exit 0