#!/bin/bash

echo Copying bootstrap.sh to payload directory
cp ${COMPONENT_DIR}/bootstrap.sh ${PAYLOAD_DIR}
cp ${COMPONENT_DIR}/files/* ${PAYLOAD_DIR}
chmod  775  ${PAYLOAD_DIR}/bootstrap.sh
