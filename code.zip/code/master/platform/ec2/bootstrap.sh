#!/bin/env bash

source /root/context

echo "bootstrap execution started"
##Required RPM Installation

for rp in  bind-utils binutils gcc gcc-c++ glibc glibc.i686 glibc-devel glibc-devel.i686 ksh libgcc libgcc.i686 libstdc++ libstdc++.i686 libstdc++-devel libstdc++-devel.i686 libaio libaio.i686 libaio-devel libaio-devel.i686 libXext libXext.i686 libXtst libXtst.i686 libX11 libX11.i686 libXau libXau.i686 libxcb libxcb.i686 libXi libXi.i686 make sysstat unixODBC unixODBC-devel zlib-devel zlib-devel.i686
do
yum install -y $rp
done

##Oracle User and  Oracle Group Installation

groupadd oinstall
useradd -g oinstall oracle

##Directory Creation for Oracle Base 

mkdir -p /u01 /root/app

##Create Swap space  for Oracle Client Installation

dd if=/dev/zero of=/swappath bs=1024 count=4096k;mkswap /swappath;echo '/swappath     swap   swap    defaults        0 0'>>/etc/fstab;swapon /swappath

##FileSystem Creation

#for dvc in `lsblk|grep -v NAME|awk -F" " '{ print "/dev/"$1}'`; do export blkdvc=`/sbin/ebsnvme-id  $dvc 2>/dev/null|tail -1 `; if [[  $blkdvc = 'sdc' ]];then export rawdevice=$dvc; echo $rawdevice; fi; done

lsblk

mkfs.xfs /dev/xvdc

echo "/dev/xvdc  /u01    xfs    defaults   0 0" >>/etc/fstab

mount  /dev/xvdc /u01

df -Ph

chown -R oracle:oinstall /u01
chmod -R 775 /u01

##DownLoad Oracle Client and Unzip the same as oracle user

if [[ `df -Ph|grep -v grep|grep -w "/u01"|wc -l` -eq 1 ]];then

echo "aws s3 cp  s3://$pipeline_QdaBucketName/linuxx64_12201_client.zip  /u01  --sse AES256; cd /u01; unzip linuxx64_12201_client.zip -d /u01"

su oracle -c "aws s3 cp  s3://$pipeline_QdaBucketName/linuxx64_12201_client.zip  /u01  --sse AES256; cd /u01; unzip linuxx64_12201_client.zip -d /u01"

cp  -r /root/payload/* /u01/

ls -ltr /u01

chmod -R 777 /u01/client_install.rsp

echo "Hostname : $HOSTNAME"

sed -i -e '/^127/s/$/ '"$HOSTNAME"'/' /etc/hosts

cat /etc/hosts

##Install Oracle Client 

su oracle -c "cd /u01/client;./runInstaller ORACLE_HOSTNAME=$HOSTNAME -silent -ignoreSysPrereqs -ignorePrereq -force -waitforcompletion -responseFile /u01/client_install.rsp"

export ORACLE_HOME=/u01/app/oracle/product/12.2.0/clienthome_1	
export PATH=$PATH:$ORACLE_HOME/bin
echo $qedwdb_DatabaseDeployDnsName

export ipaddr=`nslookup $qedwdb_DatabaseDeployDnsName|sed '/^$/d'|tail -1|awk -F"Address:" '{print $2}'|tr -d ' '`
export adminpass=`kms_decrypt $app_qedwdbadmin`
sqlplus qedwdbadmin/$adminpass@$ipaddr:1526/qedwdb <<-EOF 1>>Post_Refresh_$pipeline_Ase.log
set echo on
show user
drop database link QEDWDB_TO_TRAX;
drop database link APPS.TQNJ1I;
drop procedure CREATEODB;
alter user twdba identified by 
@/u01/Pass_Reset_App_User_$pipeline_Ase.sql
EOF

mailx -a Post_Refresh_$pipeline_Ase.log  -r qedwdb_post_refresh_$pipeline_Ase -s "Post Refresh Completion Notification for qedwdb" -S smtp=smtp://awssydmail.qcpaws.qantas.com.au rajibpodder@qantas.com.au,subhankarpandit@qantas.com.au < /u01/mailbody.txt

else

echo "File System Creation did not happen properly.Please check again...."
exit 1

fi
